# AMVGG Pet Value Scraper

Scrapes Adopt Me pet values from <https://amvgg.com/values/pets>, stores them in
`data/pets.json`, tracks changes over time in `data/history/`, and runs
automatically every 6 hours on **free GitHub Actions** (no server, no API keys).

## Read this first: what has and has not been verified

This project was built in a sandbox that **could not connect to amvgg.com**
(its network allowlist blocks the host). The only view of the site came from a
text rendering of the page. So:

| Verified (from the rendered page) | NOT verified |
|---|---|
| All pets are on one page; it ends with `Showing all N pets` (N was 803). No pagination / lazy loading was visible. | The real HTML markup: CSS classes, scripts, embedded JSON, API endpoints |
| Each pet shows: name, one number labelled `Value`, a 1-3 star `Demand`, the letters `F R N M`, a relative time ("22 hours ago") | Whether the page is server-rendered or needs JavaScript (it *looks* server-rendered, but I could not confirm) |
| | Whether GitHub's runner IPs are allowed through (many sites block datacenter IPs) |
| | Image URLs (no `<img>` markup was visible) |

Consequences, stated plainly:

* **Parser**: it matches the verified *text pattern* rather than guessed CSS selectors. It has been tested only against a **synthetic** fixture, never against the live site. Your first GitHub run is the real test.
* **Fields the list page does not show are `null`**: `rarity`, `trend`, `fly`, `ride`, `fly_ride`, `neon`, `mega_neon`. The page shows `F R N M` letters but no variant numbers. They are probably on per-pet pages or behind a toggle, which I could not inspect.
* **Assumption**: the single `Value` number is stored in both `listed_value` (exactly what the page labels it) and `values.regular`. That mapping is a convention, not something the page states. Set `ASSUME_LISTED_VALUE_IS_REGULAR = False` in `config.py` to stop mirroring it.
* **Unclear**: the first card's text reads `Baseless Frost Ride Pot Bat Dragon`. Whether "Baseless" is part of the name or a label I can't tell. The scraper preserves the text as the page gives it.
* A built-in safety net refuses to save incomplete or garbage scrapes (see *Reliability*), so a wrong guess fails loudly and leaves existing data intact instead of corrupting it.

## Project layout

```
amvgg-scraper/                  <- the CONTENTS of this folder are the repo root
├── scraper.py                  CLI, HTTP (retries/backoff/robots), orchestration
├── parser.py                   HTML -> pet records, record validation, --inspect report
├── storage.py                  atomic read/write of data/pets.json, content hashing
├── history.py                  diffing, snapshots, --history output
├── config.py                   all settings
├── requirements.txt            requests, beautifulsoup4
├── data/
│   ├── pets.json               latest data (placeholder until the first real run)
│   └── history/                timestamped snapshots
├── tests/                      30 unit/pipeline tests (stdlib unittest, offline)
└── .github/workflows/scraper.yml
```

## Setup (about 10 minutes)

### 1. Create a GitHub repository
1. Sign in at <https://github.com> → **+** (top right) → **New repository**.
2. Name it (e.g. `amvgg-scraper`). Choose **Public** (unlimited free Actions minutes) or **Private** (2,000 free minutes/month; this job uses roughly 1 hour/month).
3. Leave "Add a README" unchecked → **Create repository**.

### 2. Upload the project
The files inside `amvgg-scraper/` must sit at the **root** of the repo, so that
`.github/workflows/scraper.yml` is at the top level. Do not upload the
`amvgg-scraper` folder itself.

Command line (recommended; the web uploader can hide dot-folders):
```bash
cd amvgg-scraper
git init -b main
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/<your-username>/<repo>.git
git push -u origin main
```
Web alternative: on the empty repo page choose **uploading an existing file**,
drag in everything inside the folder (including `.github`), then commit.

### 3. Enable GitHub Actions
1. Open the repo's **Actions** tab. If you see a prompt, click **I understand my workflows, go ahead and enable them**.
2. **Settings → Actions → General → Workflow permissions** → select **Read and write permissions** → **Save**. (The workflow already requests `contents: write`, but this setting is what some accounts/orgs enforce. Without it the commit step fails with a 403.)

### 4. Run the scraper manually
**Recommended first run, which inspects the real markup:**
1. **Actions** → **Scrape AMVGG pet values** → **Run workflow**.
2. Tick **inspect** → **Run workflow**.
3. When it finishes, open the run and download the **inspect-report** artifact (or read the step's log). It shows the real scripts, any embedded JSON, whether images exist, and the HTML of the first two pet cards. It also tells you immediately if AMVGG is blocking the runner.

**Then a normal run:** same menu, leave **inspect** unticked. Watch the **Run scraper** step: it logs how many pets were parsed vs. the page's declared total.

### 5. Access and download `pets.json`
* In the repo: open `data/pets.json` → **Raw** → right-click *Save as*, or the download icon.
* Direct URL (public repos): `https://raw.githubusercontent.com/<user>/<repo>/main/data/pets.json`
* Or `git pull` locally. Everything is in the repo.

### 6. Verify the 6-hour schedule
* **Actions** tab → open the workflow → runs whose label says **schedule** (not "workflow_dispatch") are automatic. They happen at minute 17 of hours 00/06/12/18 **UTC**; GitHub often delays scheduled runs by several minutes, occasionally longer.
* A run with **no new commit is normal**: commits only happen when data changes. Check the run list, not the commit list, to confirm it is running.
* Scheduled workflows only run from the **default branch**.
* Per GitHub's docs, scheduled workflows in **public** repos are auto-disabled after 60 days without repository activity. Data-change commits normally count as activity, but if AMVGG's data stays static (or the scraper keeps failing) for that long, re-enable it on the Actions tab.
* A **red** run means the scrape failed validation or was blocked. Data is untouched; read the log.

## Command-line usage

```bash
pip install -r requirements.txt
python scraper.py              # scrape, diff, write pets.json + history snapshot
python scraper.py --dry-run    # everything except writing files
python scraper.py --check      # health check: reachable? parses? complete? writes nothing
python scraper.py --history    # list snapshots + latest changes (no network)
python scraper.py --history --pet "Shadow Dragon"   # one pet's timeline
python scraper.py --inspect    # write inspect-report.txt describing the real markup
python scraper.py --html-file saved_page.html       # parse a saved page offline (debugging)
python scraper.py --force      # skip only the "pet count dropped >20%" safety check
```
Exit code is `0` on success (including "no changes") and `1` on any failure.

## Output format

`data/pets.json` (shape shown; example values illustrate the format only):

```json
{
  "source": { "name": "AMVGG", "url": "https://amvgg.com/values/pets" },
  "last_updated": "2026-11-25T12:17:03Z",
  "total_pets": 803,
  "content_hash": "sha256:…",
  "pets": [
    {
      "id": "shadow-dragon",
      "name": "Shadow Dragon",
      "rarity": null,
      "listed_value": 3.775,
      "values": { "regular": 3.775, "fly": null, "ride": null,
                  "fly_ride": null, "neon": null, "mega_neon": null },
      "demand": "3/3",
      "demand_stars": 3,
      "trend": null,
      "image_url": null
    }
  ]
}
```
`last_updated` is the time the *content last changed*, not the time of the last
check. This is deliberate: an unchanged scrape must produce no file change and
therefore no commit.

## History

* First run → one **full** snapshot (baseline). Later runs → **delta** snapshots (added pets, removed pets, per-field old → new with direction up/down, absolute delta and %).
* A snapshot is written only when content changed; duplicates are skipped.
* Changes tracked: every value field, `listed_value`, `rarity`, `demand`, `trend`, `image_url`.
* Pets are identified by a slug of their name, so a renamed pet appears as removed + added.

## Reliability

Timeouts (10s connect / 30s read) · 4 attempts with exponential backoff + jitter and `Retry-After` support · ≥2s between requests · descriptive User-Agent · `robots.txt` honoured (the run aborts if it disallows the page or can't be read) · logging to stdout and the Actions step summary.

A scrape is **rejected, and nothing is overwritten**, if: fewer pets are parsed than the page's own `Showing all N pets`; fewer than 100 pets are found; the count drops >20% vs. the last run; <98% of pets have a numeric value; or the page looks like a CAPTCHA/anti-bot challenge. A 401/403 is reported as "blocked" and **not** worked around.

## If the first run fails or fields are missing

1. **`HTTP 403` / "blocked" / challenge page**: AMVGG is refusing GitHub's runner IPs or bots. This project will not bypass that. Options: contact the site owner about access, or ask whether they provide an official data feed.
2. **"No pets parsed" but no block**: run with `inspect`. If the report shows an empty shell with data in a `<script>` JSON blob or in JS-loaded API calls, the parser needs adapting (and Playwright is only warranted if the data truly requires JS execution).
3. **Variant values (fly/ride/neon/mega) are null**: that is expected until the markup shows where they live. Use the inspect report (look at the card HTML, its links, and any `data-*` attributes), then extend `parse_page()` in `parser.py` to fill `values[...]`. Rarity, trend and image URL are the same story.
4. **Timeouts**: raise `READ_TIMEOUT` / `MAX_RETRIES` in `config.py`.

## Tests

```bash
python -m unittest discover -s tests -v
```
30 offline tests (parser, diffing, hashing, and the full pipeline including
failure cases: incomplete scrape, blocked page, big drop, dry-run, check, history).
They use a **synthetic** HTML fixture with invented markup. They prove the logic,
not compatibility with AMVGG's real markup.

## Terms and responsible use

The scraper makes one page request (plus `robots.txt`) per run, 4 runs/day, and
does not log in or bypass any access control. AMVGG links Terms of Service from
its footer: **read them yourself** before relying on this; I could not confirm
whether automated access is permitted. AMVGG states it is not affiliated with Uplift Games.
